 
import './ColorList.css'; 

const ColorList = () => {
 
	return (
		<ul className="color-box">
			   
		</ul>
	);
};

export default ColorList;