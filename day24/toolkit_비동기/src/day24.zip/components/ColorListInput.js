const ColorListInput = () => {

    return (
        <form className="ColorList"  >
					<input	 placeholder="원하는 색을 입력하세요" />
		</form>
    );
};

export default ColorListInput;