const ColorListItem = ( ) => {
    
    return (
        <li>
            
        </li>
    );
};

export default ColorListItem;