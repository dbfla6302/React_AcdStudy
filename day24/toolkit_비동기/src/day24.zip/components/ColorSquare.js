import './ColorSquare.css'; 

const ColorSquare = () => {
	return (
		<div className="ColorSquare">
				
		</div>
	);
};

export default ColorSquare;

