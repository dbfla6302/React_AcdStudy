const ColorSquareItem = () => {
	return (
		<div className="Color">
			
		</div>	
	);
};

export default ColorSquareItem;