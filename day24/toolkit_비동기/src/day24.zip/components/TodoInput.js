const TodoInput = () => {

    return (
        <form  >
        <input type="text" placeholder="이름을 입력하세요"  />
    </form>
    );
};

export default TodoInput;