 const TodoItem = ( ) => {
   
    return (
        <li > 
        <span  >
            대기번호 :    &nbsp;&nbsp;&nbsp;    </span>
        <button> 수정</button>
        <button> 삭제</button>
    </li>
    );
};

export default TodoItem;